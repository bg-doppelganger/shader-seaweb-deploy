# セットアップ方法

Three.js のシェーダー開発するための開発環境です。
リポジトリからソースをダウンロードして、VSCode に張り付けてください。

貼り付けたら以下のコマンドを実行してください。

```bash
npm install
```

# ライセンス

このリポジトリは[MIT license](https://en.wikipedia.org/wiki/MIT_License)です。
"# threejs-sea-setup" 
